#!/usr/bin/env python3
"""Fast, offline structural regression checks for Liquid Files."""
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
ANDROID = '{http://schemas.android.com/apk/res/android}'

def require(condition, message):
    if not condition:
        raise AssertionError(message)
    print(f'PASS: {message}')

def main():
    required = [
        'settings.gradle.kts', 'build.gradle.kts', 'app/build.gradle.kts',
        'gradle/wrapper/gradle-wrapper.jar', 'gradle/wrapper/gradle-wrapper.properties',
        'gradlew', 'gradlew.bat', 'app/src/main/AndroidManifest.xml',
        'app/src/main/java/com/music/echo/offline/files/MainActivity.java',
        'app/src/main/java/com/music/echo/offline/files/FileOps.java',
        '.github/workflows/android-build.yml',
    ]
    for rel in required:
        path = ROOT / rel
        require(path.is_file() and path.stat().st_size > 0, f'required project file exists: {rel}')

    manifest_path = ROOT / 'app/src/main/AndroidManifest.xml'
    manifest = ET.parse(manifest_path).getroot()
    perms = {n.attrib.get(ANDROID + 'name') for n in manifest.findall('uses-permission')}
    require('android.permission.INTERNET' in perms, 'manifest declares INTERNET permission used by optional LAN features')
    require('android.permission.FOREGROUND_SERVICE' in perms and 'android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK' in perms, 'foreground media-playback permissions declared for built-in background audio')
    app = manifest.find('application')
    require(app is not None, 'manifest has application node')
    launcher = []
    for activity in app.findall('activity'):
        filt = activity.find('intent-filter')
        if filt is not None:
            actions = {x.attrib.get(ANDROID + 'name') for x in filt.findall('action')}
            cats = {x.attrib.get(ANDROID + 'name') for x in filt.findall('category')}
            if 'android.intent.action.MAIN' in actions and 'android.intent.category.LAUNCHER' in cats:
                launcher.append(activity.attrib.get(ANDROID + 'name'))
    require(launcher == ['.files.MainActivity'], 'file manager remains the only launcher activity')

    file_ui = (ROOT / 'app/src/main/java/com/music/echo/offline/files/MainActivity.java').read_text()
    settings = (ROOT / 'app/src/main/java/com/music/echo/offline/files/MainActivity.java').read_text()
    require('Internet permission supports optional local Wi-Fi transfer' in file_ui,
            'file-manager privacy text accurately describes network permission')
    require('startActivity(new Intent(this, com.music.echo.offline.ui.MainActivity.class))' not in file_ui,
            'file-manager Audio tab does not launch the separate Compose player')
    activity_names = {a.attrib.get(ANDROID + 'name') for a in app.findall('activity')}
    service_names = {a.attrib.get(ANDROID + 'name') for a in app.findall('service')}
    require('.ui.MainActivity' not in activity_names and '.playback.MusicService' not in service_names,
            'separate Compose player and MusicService are not registered in the app manifest')
    require('.files.BackgroundAudioService' in service_names, 'built-in foreground audio service is registered')
    require('Export settings' in settings and 'Import settings' in settings, 'file manager settings backup and restore remain available')
    require('toUpperCase(java.util.Locale.ROOT)' in settings, 'settings categories use consistent compact section headings')
    require('No internet permission' not in settings,
            'no contradictory claim that INTERNET permission is absent')

    gradle = (ROOT / 'app/build.gradle.kts').read_text()
    require('applicationId = "com.liquidfiles.offline"' in gradle, 'fresh application ID is configured')
    require('org.jetbrains.kotlin' not in gradle and 'com.google.devtools.ksp' not in gradle, 'unused Kotlin and KSP build plugins removed')
    require(not (ROOT / 'app/src/main/kotlin').exists(), 'unused Echo-derived Compose player source tree removed')
    workflow = (ROOT / '.github/workflows/android-build.yml').read_text()
    require('pull_request:' in workflow and 'assembleDebug' in workflow,
            'CI runs on pull requests and compiles debug APK')
    require('project ZIP not found' not in workflow and 'unzip -q' not in workflow,
            'CI builds source at repository root, not a nested ZIP')

    service_path = ROOT / 'app/src/main/java/com/music/echo/offline/files/BackgroundAudioService.java'
    service = service_path.read_text()
    require('private void prepareNext()' in service and 'private void promoteNext()' in service,
            'background audio preloads and promotes the next queue item')
    require('private final Runnable crossfadeTick' in service and 'crossfadeStartedAt' in service,
            'background crossfade lifecycle is present')
    require('if (player != mp)' in service and 'if (player == mp)' in service,
            'stale asynchronous player callbacks cannot replace current playback')
    require('handler.postDelayed(this, 250)' in service and 'if (player != null && prepared)' in service,
            'background progress ticker remains scheduled while prepared')
    require('player.pause()' in service and 'nextPlayer.pause()' in service,
            'pause path accounts for both sides of an active crossfade')
    require('pausedForTransientFocusLoss' in service and 'change == AudioManager.AUDIOFOCUS_LOSS' in service,
            'permanent audio-focus loss does not automatically resume playback')
    require('ACTION_PAUSE.equals(action)) { pausedForTransientFocusLoss = false; pause(); }' in service,
            'explicit notification pause clears transient-focus auto-resume intent')
    require('focusGranted = result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED' in service and 'if (focusGranted)' in service,
            'background playback respects denied audio focus')
    require('abandonAudioFocusRequest(focusRequest)' in service and 'private void stopPlayback()' in service,
            'audio focus is released when playback stops')
    require('releaseNext();\n                prepareNext();' in service,
            'same-track handoff refreshes preloaded queue item')
    require('playbackVolume = intent == null ? 1.0f' in service and 'setVolume(playbackVolume, playbackVolume)' in service,
            'background playback honors the foreground volume setting')
    viewer = (ROOT / 'app/src/main/java/com/music/echo/offline/files/ViewerActivity.java').read_text()
    require('USAGE_MEDIA' in viewer and 'CONTENT_TYPE_MUSIC' in viewer,
            'foreground player declares standard media audio attributes')
    require('putInt("audio_volume", value)' in viewer and 'putExtra("volume", audioVolume)' in viewer,
            'audio volume persists and transfers to background playback')
    require('void showQueueEditor()' in viewer and 'Collections.swap(paths, position, position - 1)' in viewer
            and 'paths.remove(position)' in viewer, 'playback queue supports reordering and removal')
    require('Frame −/＋' not in viewer and 'frameForward' not in viewer
            and 'if (!videoLoop) advanceToNextVideo();' in viewer,
            'unsupported frame-step control is removed and videos auto-advance on completion unless repeat is enabled')
    require('Audio only' not in viewer and 'Aspect ratio' not in viewer and 'Audio & subtitle tracks' not in viewer
            and 'Skip intro / outro' not in viewer and 'video_marker_' not in viewer,
            'removed video-player audio-only, aspect, track picker, and intro/outro controls')
    require('enterVideoImmersiveMode();' in viewer and 'WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE' in viewer
            and 'LinearLayout primaryRow' in viewer and 'LinearLayout secondaryRow' in viewer
            and 'setMediaController' not in viewer and 'SeekBar seekBar' in viewer
            and 'formatVideoTime' in viewer,
            'video playback uses immersive full-screen mode and an integrated seek/play control dock')
    print('\nAll structural smoke checks passed. This is not a substitute for Android compilation or device testing.')

if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print(f'FAIL: {exc}', file=sys.stderr)
        sys.exit(1)
