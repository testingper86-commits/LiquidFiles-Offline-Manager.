# LiquidFiles Offline Manager — build recovery notes

This source archive contains the Android project and its Gradle wrapper. The companion `LiquidFiles_Offline_Manager_Build_FIXED.yml` is an archive-aware GitHub Actions workflow intended to be committed under `.github/workflows/` in the repository that stores this ZIP.

The workflow searches for `LiquidFiles_Offline_Manager_PERMANENT_FIX_UPDATED.zip` in the repository root, extracts it, runs the project structural smoke tests and Android XML parsing, then runs `assembleDebug` and uploads the APK as a workflow artifact.

Validation performed while packaging: `tools/project_smoke_test.py` passed all structural checks. Android SDK compilation and device installation have not been verified in this packaging environment; the GitHub Actions run must confirm those.
