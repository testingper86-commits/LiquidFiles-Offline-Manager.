## Summary
- [ ] Describe the code or UI change.

## Verification
- [ ] `python tools/project_smoke_test.py`
- [ ] `./gradlew assembleDebug`
- [ ] Tested install/launch on an Android device (state Android version)
- [ ] Tested any file operations affected by this PR

## Known limitations
List any untested paths or device-specific behavior. Do not mark device tests complete unless they were actually run.
