#!/usr/bin/env python3
"""Fast, offline structural regression checks for Liquid Files."""
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
ANDROID = '{http://schemas.android.com/apk/res/android}'

def require(condition, message):
    if not condition:
        raise AssertionError(message)
    print(f'PASS: {message}')

def main():
    required = [
        'settings.gradle.kts', 'build.gradle.kts', 'app/build.gradle.kts',
        'gradle/wrapper/gradle-wrapper.jar', 'gradle/wrapper/gradle-wrapper.properties',
        'gradlew', 'gradlew.bat', 'app/src/main/AndroidManifest.xml',
        'app/src/main/java/com/music/echo/offline/files/MainActivity.java',
        'app/src/main/java/com/music/echo/offline/files/FileOps.java',
        '.github/workflows/android-build.yml',
    ]
    for rel in required:
        path = ROOT / rel
        require(path.is_file() and path.stat().st_size > 0, f'required project file exists: {rel}')

    manifest_path = ROOT / 'app/src/main/AndroidManifest.xml'
    manifest = ET.parse(manifest_path).getroot()
    perms = {n.attrib.get(ANDROID + 'name') for n in manifest.findall('uses-permission')}
    require('android.permission.INTERNET' in perms, 'manifest declares INTERNET permission used by optional LAN features')
    require('android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK' not in perms, 'unused media-service permissions removed')
    app = manifest.find('application')
    require(app is not None, 'manifest has application node')
    launcher = []
    for activity in app.findall('activity'):
        filt = activity.find('intent-filter')
        if filt is not None:
            actions = {x.attrib.get(ANDROID + 'name') for x in filt.findall('action')}
            cats = {x.attrib.get(ANDROID + 'name') for x in filt.findall('category')}
            if 'android.intent.action.MAIN' in actions and 'android.intent.category.LAUNCHER' in cats:
                launcher.append(activity.attrib.get(ANDROID + 'name'))
    require(launcher == ['.files.MainActivity'], 'file manager remains the only launcher activity')

    file_ui = (ROOT / 'app/src/main/java/com/music/echo/offline/files/MainActivity.java').read_text()
    settings = (ROOT / 'app/src/main/java/com/music/echo/offline/files/MainActivity.java').read_text()
    require('Internet permission supports optional local Wi-Fi transfer' in file_ui,
            'file-manager privacy text accurately describes network permission')
    require('startActivity(new Intent(this, com.music.echo.offline.ui.MainActivity.class))' not in file_ui,
            'file-manager Audio tab does not launch the separate Compose player')
    activity_names = {a.attrib.get(ANDROID + 'name') for a in app.findall('activity')}
    service_names = {a.attrib.get(ANDROID + 'name') for a in app.findall('service')}
    require('.ui.MainActivity' not in activity_names and '.playback.MusicService' not in service_names,
            'separate Compose player and MusicService are not registered in the app manifest')
    require('Export settings' in settings and 'Import settings' in settings, 'file manager settings backup and restore remain available')
    require('toUpperCase(java.util.Locale.ROOT)' in settings, 'settings categories use consistent compact section headings')
    require('No internet permission' not in settings,
            'no contradictory claim that INTERNET permission is absent')

    gradle = (ROOT / 'app/build.gradle.kts').read_text()
    require('applicationId = "com.liquidfiles.offline"' in gradle, 'fresh application ID is configured')
    require('org.jetbrains.kotlin' not in gradle and 'com.google.devtools.ksp' not in gradle, 'unused Kotlin and KSP build plugins removed')
    require(not (ROOT / 'app/src/main/kotlin').exists(), 'unused Echo-derived Compose player source tree removed')
    workflow = (ROOT / '.github/workflows/android-build.yml').read_text()
    require('pull_request:' in workflow and 'assembleDebug' in workflow,
            'CI runs on pull requests and compiles debug APK')
    require('project ZIP not found' not in workflow and 'unzip -q' not in workflow,
            'CI builds source at repository root, not a nested ZIP')
    print('\nAll structural smoke checks passed. This is not a substitute for Android compilation or device testing.')

if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print(f'FAIL: {exc}', file=sys.stderr)
        sys.exit(1)
