package com.music.echo.offline.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.music.echo.offline.ui.LocalBottomPad
import com.music.echo.offline.ui.MainViewModel
import com.music.echo.offline.ui.components.*
import java.util.Locale

@Composable
fun StatsScreen(vm: MainViewModel, onBack: () -> Unit) {
    val history by vm.history.collectAsState()
    val map by vm.songMap.collectAsState()

    val rows = remember(history, map) { history.mapNotNull { h -> map[h.songId]?.let { it to h.playCount } } }
    val totalPlays = rows.sumOf { it.second }
    val hours = rows.sumOf { (s, c) -> s.durationMs * c.toLong() } / 3_600_000.0
    val topSongs = rows.sortedByDescending { it.second }.take(10)
    val topArtists = rows.groupBy { it.first.artist }.map { (a, l) -> a to l.sumOf { it.second } }
        .sortedByDescending { it.second }.take(8)

    Column(Modifier.fillMaxSize()) {
        BackHeader("Listening stats", onBack)
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = LocalBottomPad.current),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Plays", totalPlays.toString(), Modifier.weight(1f))
                StatCard("Hours (est.)", String.format(Locale.US, "%.1f", hours), Modifier.weight(1f))
                StatCard("Songs", rows.size.toString(), Modifier.weight(1f))
            }
            if (rows.isEmpty()) EmptyState("Play some music and your stats will show up here.")
            if (topSongs.isNotEmpty()) {
                Text("Top songs", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Column(Modifier.fillMaxWidth().softCard().padding(vertical = 8.dp)) {
                    topSongs.forEachIndexed { i, (s, c) ->
                        Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${i + 1}", Modifier.width(28.dp), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            ArtImage(s, Modifier.size(40.dp))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(s.title, maxLines = 1, fontWeight = FontWeight.SemiBold)
                                Text(s.artist, maxLines = 1, style = MaterialTheme.typography.bodySmall)
                            }
                            Text("$c×", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            if (topArtists.isNotEmpty()) {
                Text("Top artists", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Column(Modifier.fillMaxWidth().softCard().padding(vertical = 8.dp)) {
                    topArtists.forEachIndexed { i, (a, c) ->
                        Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                            Text("${i + 1}", Modifier.width(28.dp), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Text(a, Modifier.weight(1f), maxLines = 1, fontWeight = FontWeight.SemiBold)
                            Text("$c plays", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            Text(
                "A play is counted each time a song starts. Hours are estimated from song length × plays.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier) {
    Column(modifier.softCard().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
