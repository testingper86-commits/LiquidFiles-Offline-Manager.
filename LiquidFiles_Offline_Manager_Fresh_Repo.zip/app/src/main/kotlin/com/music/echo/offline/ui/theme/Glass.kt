package com.music.echo.offline.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * A layered Liquid Glass surface with a soft tint, luminous top edge and subtle colour bloom.
 * This intentionally does not claim to blur arbitrary content behind the surface: Compose's
 * regular background modifier cannot provide true backdrop blur without a dedicated blur host.
 * The surface remains readable and compatible with the project's current dependency set.
 */
@Composable
fun Modifier.glass(shape: Shape, blur: Dp = 24.dp, opacity: Float = 0.4f): Modifier {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val tint = if (dark) Color(0xFF151827) else Color(0xFFFDFEFF)
    val safeOpacity = opacity.coerceIn(0.12f, 0.92f)
    val fill = Brush.verticalGradient(
        colors = listOf(
            tint.copy(alpha = (safeOpacity + 0.18f).coerceAtMost(0.96f)),
            tint.copy(alpha = safeOpacity),
            MaterialTheme.colorScheme.primary.copy(alpha = if (dark) 0.075f else 0.035f),
        ),
    )
    val rim = Brush.linearGradient(
        colors = listOf(
            Color.White.copy(alpha = if (dark) 0.42f else 0.96f),
            MaterialTheme.colorScheme.primary.copy(alpha = if (dark) 0.20f else 0.12f),
            Color.White.copy(alpha = 0.06f),
        ),
    )
    return this.clip(shape)
        .background(fill, shape)
        .border(0.8.dp, rim, shape)
}
