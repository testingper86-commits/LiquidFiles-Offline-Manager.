package com.music.echo.offline.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import android.content.Intent
import com.music.echo.offline.files.MainActivity as FileManagerActivity
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.navArgument
import com.music.echo.offline.data.UiStyle
import com.music.echo.offline.ui.components.PlaylistPickerDialog
import com.music.echo.offline.ui.player.MiniPlayer
import com.music.echo.offline.ui.player.PlayerScreen
import com.music.echo.offline.ui.screens.*
import com.music.echo.offline.ui.theme.LocalUiStyle
import com.music.echo.offline.ui.theme.glass

val LocalBottomPad = compositionLocalOf<Dp> { 160.dp }

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("home", "Home", Icons.Rounded.Home),
    Tab("library", "Library", Icons.Rounded.LibraryMusic),
    Tab("browse", "Browse", Icons.Rounded.FolderOpen),
    Tab("search", "Search", Icons.Rounded.Search),
    Tab("settings", "Settings", Icons.Rounded.Settings),
)

@Composable
fun AppScaffold(vm: MainViewModel) {
    val context = LocalContext.current
    val nav = rememberNavController()
    val style = LocalUiStyle.current
    val glass = style == UiStyle.Glass
    var playerOpen by rememberSaveable { mutableStateOf(false) }
    val ps by vm.player.state.collectAsState()
    val hasSong = ps.currentId != null
    val entry by nav.currentBackStackEntryAsState()
    var selectedTab by rememberSaveable { mutableStateOf("home") }
    LaunchedEffect(entry) {
        entry?.destination?.route?.let { r -> if (tabs.any { it.route == r }) selectedTab = r }
    }
    val pick by vm.pickPlaylistFor.collectAsState()
    LaunchedEffect(playerOpen) { MainActivity.playerVisible.value = playerOpen }

    val navInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val bottomPad = navInset + 96.dp + (if (hasSong) 76.dp else 0.dp)

    CompositionLocalProvider(
        LocalBottomPad provides bottomPad,
    ) {
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
            Box(Modifier.fillMaxSize()) {
                NavHost(nav, startDestination = "home", modifier = Modifier.fillMaxSize()) {
                    composable("home") {
                        HomeScreen(vm, { nav.navigate("collection/$it") }, { nav.navigate("album/$it") })
                    }
                    composable("library") {
                        LibraryScreen(
                            vm,
                            onOpenAlbum = { nav.navigate("album/$it") },
                            onOpenArtist = { nav.navigate("artist/$it") },
                            onOpenPlaylist = { nav.navigate("playlist/$it") },
                            onOpenCollection = { nav.navigate("collection/$it") },
                            onOpenFolder = { nav.navigate("folder/$it") },
                            onOpenStats = { nav.navigate("stats") },
                        )
                    }
                    composable("search") {
                        SearchScreen(vm, { nav.navigate("album/$it") }, { nav.navigate("artist/$it") })
                    }
                    composable("settings") { SettingsScreen(vm) { nav.navigate("equalizer") } }
                    composable("stats") { StatsScreen(vm) { nav.popBackStack() } }
                    composable("folder/{path}", listOf(navArgument("path") { type = NavType.StringType })) {
                        FolderScreen(it.arguments!!.getString("path").orEmpty(), vm) { nav.popBackStack() }
                    }
                    composable("equalizer") { EqualizerScreen(vm) { nav.popBackStack() } }
                    composable("album/{id}", listOf(navArgument("id") { type = NavType.LongType })) {
                        AlbumScreen(it.arguments!!.getLong("id"), vm) { nav.popBackStack() }
                    }
                    composable("artist/{name}", listOf(navArgument("name") { type = NavType.StringType })) {
                        ArtistScreen(it.arguments!!.getString("name").orEmpty(), vm) { nav.popBackStack() }
                    }
                    composable("playlist/{id}", listOf(navArgument("id") { type = NavType.LongType })) {
                        PlaylistScreen(it.arguments!!.getLong("id"), vm) { nav.popBackStack() }
                    }
                    composable("collection/{kind}", listOf(navArgument("kind") { type = NavType.StringType })) {
                        CollectionScreen(it.arguments!!.getString("kind").orEmpty(), vm) { nav.popBackStack() }
                    }
                }
            }

            Column(Modifier.align(Alignment.BottomCenter)) {
                if (hasSong) MiniPlayer(vm, onOpen = { playerOpen = true }, modifier = Modifier.padding(bottom = 6.dp))
                TabBar(glass, selectedTab) { route ->
                    if (route == "browse") {
                        context.startActivity(Intent(context, FileManagerActivity::class.java))
                    } else {
                        selectedTab = route
                        nav.navigate(route) {
                            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                }
            }

            AnimatedVisibility(
                visible = playerOpen,
                enter = slideInVertically { it },
                exit = slideOutVertically { it },
            ) {
                PlayerScreen(vm, onClose = { playerOpen = false }, onOpenEqualizer = {
                    playerOpen = false
                    nav.navigate("equalizer")
                })
            }
            BackHandler(enabled = playerOpen) { playerOpen = false }

            pick?.let { PlaylistPickerDialog(vm, it) { vm.pickPlaylistFor.value = null } }
        }
    }
}

@Composable
private fun TabBar(glass: Boolean, selected: String, onSelect: (String) -> Unit) {
    if (!glass) {
        NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
            tabs.forEach { t ->
                NavigationBarItem(
                    selected = selected == t.route, onClick = { onSelect(t.route) },
                    icon = { Icon(t.icon, t.label) }, label = { Text(t.label) },
                )
            }
        }
        return
    }
    // Floating Liquid Glass tab bar
    Row(
        Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 24.dp, vertical = 8.dp)
            .height(64.dp).glass(CircleShape).padding(6.dp),
        horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically,
    ) {
        tabs.forEach { t ->
            val sel = selected == t.route
            Column(
                Modifier.weight(1f).fillMaxHeight().clip(CircleShape)
                    .background(if (sel) MaterialTheme.colorScheme.primary.copy(alpha = 0.22f) else androidx.compose.ui.graphics.Color.Transparent)
                    .clickable { onSelect(t.route) },
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
            ) {
                Icon(t.icon, t.label, Modifier.size(24.dp), tint = if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                Text(
                    t.label, style = MaterialTheme.typography.labelSmall,
                    color = if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                )
            }
        }
    }
}
