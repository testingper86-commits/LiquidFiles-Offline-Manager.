package com.music.echo.offline.ui.screens

import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.music.echo.offline.ui.LocalBottomPad
import com.music.echo.offline.ui.MainViewModel
import com.music.echo.offline.ui.components.*

@Composable
fun SearchScreen(vm: MainViewModel, onOpenAlbum: (Long) -> Unit, onOpenArtist: (String) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    val songs by vm.songs.collectAsState()
    val albums by vm.albums.collectAsState()
    val artists by vm.artists.collectAsState()
    val ps by vm.player.state.collectAsState()
    val q = query.trim().lowercase()

    val songHits = remember(q, songs) {
        if (q.isEmpty()) emptyList() else songs.filter {
            it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) || it.album.lowercase().contains(q)
        }.take(60)
    }
    val albumHits = remember(q, albums) { if (q.isEmpty()) emptyList() else albums.filter { it.name.lowercase().contains(q) }.take(10) }
    val artistHits = remember(q, artists) { if (q.isEmpty()) emptyList() else artists.filter { it.name.lowercase().contains(q) }.take(10) }

    Column(Modifier.fillMaxSize()) {
        Text(
            "Search", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.statusBarsPadding().padding(start = 20.dp, top = 16.dp, bottom = 8.dp),
        )
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            placeholder = { Text("Songs, albums, artists") },
            leadingIcon = { Icon(Icons.Rounded.Search, null) },
            trailingIcon = { if (query.isNotEmpty()) IconButton({ query = "" }) { Icon(Icons.Rounded.Close, "Clear") } },
            shape = CircleShape,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
        )
        LazyColumn(contentPadding = PaddingValues(top = 8.dp, bottom = LocalBottomPad.current)) {
            if (q.isNotEmpty() && songHits.isEmpty() && albumHits.isEmpty() && artistHits.isEmpty()) {
                item { EmptyState("No results for “$query”") }
            }
            if (artistHits.isNotEmpty()) {
                item { SectionTitle("Artists") }
                items(artistHits, key = { "ar-" + it.name }) { a ->
                    ListItem(
                        headlineContent = { Text(a.name) }, supportingContent = { Text("${a.songs.size} songs") },
                        leadingContent = { ArtImage(a.songs.first(), Modifier.size(48.dp), CircleShape) },
                        modifier = Modifier.clickable { onOpenArtist(Uri.encode(a.name)) },
                        colors = ListItemDefaults.colors(containerColor = androidx.compose.ui.graphics.Color.Transparent),
                    )
                }
            }
            if (albumHits.isNotEmpty()) {
                item { SectionTitle("Albums") }
                items(albumHits, key = { "al-" + it.id }) { a ->
                    ListItem(
                        headlineContent = { Text(a.name) }, supportingContent = { Text(a.artist) },
                        leadingContent = { ArtImage(a.songs.first(), Modifier.size(48.dp)) },
                        modifier = Modifier.clickable { onOpenAlbum(a.id) },
                        colors = ListItemDefaults.colors(containerColor = androidx.compose.ui.graphics.Color.Transparent),
                    )
                }
            }
            if (songHits.isNotEmpty()) {
                item { SectionTitle("Songs") }
                itemsIndexed(songHits, key = { _, s -> "s-" + s.id }) { i, s ->
                    SongRow(s, vm, ps.currentId == s.id, onClick = { vm.player.play(songHits, i) })
                }
            }
        }
    }
}
