package com.music.echo.offline.ui.player

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.music.echo.offline.data.LyricLine
import com.music.echo.offline.data.Song
import com.music.echo.offline.ui.MainViewModel
import kotlinx.coroutines.launch

@Composable
fun LyricsView(vm: MainViewModel, song: Song, fg: Color, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    var version by remember { mutableIntStateOf(0) }
    val lines by produceState<List<LyricLine>?>(null, song.id, version) { value = vm.lyricsStore.load(song.id) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { scope.launch { vm.lyricsStore.import(song.id, it); version++ } }
    }
    val pos by vm.player.position.collectAsState()

    val ls = lines
    if (ls == null) {
        Column(modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("No lyrics for this song", color = fg.copy(alpha = 0.8f), fontWeight = FontWeight.SemiBold)
            Text(
                "Import a .lrc file (synced) or .txt file. It's stored on your device only.",
                color = fg.copy(alpha = 0.6f), textAlign = TextAlign.Center, modifier = Modifier.padding(16.dp),
            )
            FilledTonalButton(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Import lyrics") }
        }
        return
    }

    val synced = ls.first().timeMs >= 0
    val current = if (synced) ls.indexOfLast { it.timeMs <= pos } else -1
    val state = rememberLazyListState()
    LaunchedEffect(current) { if (current >= 0) state.animateScrollToItem((current - 2).coerceAtLeast(0)) }

    Box(modifier.fillMaxWidth()) {
        LazyColumn(state = state, contentPadding = PaddingValues(vertical = 60.dp), modifier = Modifier.fillMaxSize()) {
            itemsIndexed(ls) { i, line ->
                val active = !synced || i == current
                Text(
                    line.text.ifBlank { "♪" },
                    fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 32.sp,
                    color = fg.copy(alpha = if (active) 1f else 0.38f),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                        .clickable(enabled = synced) { vm.player.seekTo(line.timeMs) },
                )
            }
        }
        Row(Modifier.align(Alignment.TopEnd)) {
            TextButton(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Replace", color = fg.copy(alpha = 0.8f)) }
            TextButton(onClick = { scope.launch { vm.lyricsStore.delete(song.id); version++ } }) {
                Text("Remove", color = fg.copy(alpha = 0.8f))
            }
        }
    }
}
