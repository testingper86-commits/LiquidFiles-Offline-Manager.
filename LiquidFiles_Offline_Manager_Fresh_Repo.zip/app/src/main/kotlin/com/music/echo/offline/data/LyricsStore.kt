package com.music.echo.offline.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** timeMs < 0 means the line is unsynced. */
data class LyricLine(val timeMs: Long, val text: String)

/** Lyrics live in app-private storage; the user imports .lrc / .txt files per song. */
class LyricsStore(private val ctx: Context) {
    private val dir = File(ctx.filesDir, "lyrics").apply { mkdirs() }
    private fun file(id: Long) = File(dir, "$id.lrc")

    suspend fun load(id: Long): List<LyricLine>? = withContext(Dispatchers.IO) {
        file(id).takeIf { it.exists() }?.readText()?.let(::parse)?.takeIf { it.isNotEmpty() }
    }

    suspend fun import(id: Long, uri: Uri): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val text = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes().toString(Charsets.UTF_8) }
            file(id).writeText(text)
            true
        }.getOrDefault(false)
    }

    suspend fun delete(id: Long) = withContext(Dispatchers.IO) { file(id).delete(); Unit }

    companion object {
        private val tag = Regex("""\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?]""")

        fun parse(text: String): List<LyricLine> {
            val synced = ArrayList<LyricLine>()
            val plain = ArrayList<LyricLine>()
            for (raw in text.lines()) {
                val line = raw.trim()
                if (line.isEmpty()) continue
                val matches = tag.findAll(line).toList()
                if (matches.isEmpty()) {
                    if (!line.startsWith("[")) plain += LyricLine(-1, line)
                    continue
                }
                val body = line.substring(matches.last().range.last + 1).trim()
                for (m in matches) {
                    val min = m.groupValues[1].toLong()
                    val sec = m.groupValues[2].toLong()
                    val frac = m.groupValues[3]
                    val ms = when (frac.length) { 0 -> 0L; 1 -> frac.toLong() * 100; 2 -> frac.toLong() * 10; else -> frac.toLong() }
                    synced += LyricLine(min * 60_000 + sec * 1000 + ms, body)
                }
            }
            return if (synced.isNotEmpty()) synced.sortedBy { it.timeMs } else plain
        }
    }
}
