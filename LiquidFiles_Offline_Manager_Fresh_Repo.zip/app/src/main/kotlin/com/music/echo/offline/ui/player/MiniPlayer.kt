package com.music.echo.offline.ui.player

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.music.echo.offline.data.UiStyle
import com.music.echo.offline.ui.MainViewModel
import com.music.echo.offline.ui.components.ArtImage
import com.music.echo.offline.ui.theme.LocalUiStyle
import com.music.echo.offline.ui.theme.glass

@Composable
fun MiniPlayer(vm: MainViewModel, onOpen: () -> Unit, modifier: Modifier = Modifier) {
    val ps by vm.player.state.collectAsState()
    val pos by vm.player.position.collectAsState()
    val map by vm.songMap.collectAsState()
    val song = ps.currentId?.let { map[it] } ?: return
    val shape = RoundedCornerShape(24.dp)
    val glass = LocalUiStyle.current == UiStyle.Glass
    val base = if (glass) Modifier.glass(shape)
    else Modifier.clip(shape).background(MaterialTheme.colorScheme.surfaceContainerHigh)

    Column(modifier.fillMaxWidth().padding(horizontal = 12.dp).then(base).clickable(onClick = onOpen)
        .pointerInput(Unit) {
            var total = 0f
            detectHorizontalDragGestures(
                onDragStart = { total = 0f },
                onDragEnd = { if (total < -90) vm.player.next() else if (total > 90) vm.player.previous() },
            ) { _, d -> total += d }
        },
    ) {
        Row(Modifier.padding(start = 10.dp, end = 4.dp, top = 8.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            ArtImage(song, Modifier.size(48.dp), RoundedCornerShape(14.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                Text(
                    song.artist, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            IconButton(onClick = { vm.player.togglePlay() }) {
                Icon(if (ps.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "Play/Pause", Modifier.size(30.dp))
            }
            IconButton(onClick = { vm.player.next() }) { Icon(Icons.Rounded.SkipNext, "Next", Modifier.size(28.dp)) }
        }
        LinearProgressIndicator(
            progress = { (pos.toFloat() / (ps.durationMs.takeIf { it > 0 } ?: song.durationMs).coerceAtLeast(1)).coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(2.dp),
            trackColor = androidx.compose.ui.graphics.Color.Transparent,
        )
    }
}
