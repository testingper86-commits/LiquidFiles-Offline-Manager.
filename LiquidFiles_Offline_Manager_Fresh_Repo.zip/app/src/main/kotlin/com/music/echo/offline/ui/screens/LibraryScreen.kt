package com.music.echo.offline.ui.screens

import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.Dp
import com.music.echo.offline.data.Keys
import com.music.echo.offline.ui.LocalBottomPad
import com.music.echo.offline.ui.MainViewModel
import com.music.echo.offline.ui.components.*

@Composable
fun LibraryScreen(
    vm: MainViewModel,
    onOpenAlbum: (Long) -> Unit,
    onOpenArtist: (String) -> Unit,
    onOpenPlaylist: (Long) -> Unit,
    onOpenCollection: (String) -> Unit,
    onOpenFolder: (String) -> Unit,
    onOpenStats: () -> Unit,
) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val songs by vm.sortedSongs.collectAsState()
    val folders by vm.folders.collectAsState()
    val settings by vm.settings.collectAsState()
    var sortMenu by remember { mutableStateOf(false) }
    val albums by vm.albums.collectAsState()
    val artists by vm.artists.collectAsState()
    val playlists by vm.playlists.collectAsState()
    val ps by vm.player.state.collectAsState()
    val scanning by vm.scanning.collectAsState()
    var newPlaylist by remember { mutableStateOf(false) }
    val pad = LocalBottomPad.current

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.statusBarsPadding().padding(start = 20.dp, end = 8.dp, top = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Library", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
            if (tab == 0) Box {
                IconButton(onClick = { sortMenu = true }) { Icon(Icons.Rounded.Sort, "Sort") }
                DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                    listOf("Title", "Artist", "Newest", "Longest").forEachIndexed { i, label ->
                        DropdownMenuItem(
                            text = { Text(label, fontWeight = if (settings.sort == i) FontWeight.Bold else FontWeight.Normal) },
                            onClick = { vm.set(Keys.SORT, i); sortMenu = false },
                        )
                    }
                }
            }
            if (scanning) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
            else IconButton(onClick = { vm.rescan() }) { Icon(Icons.Rounded.Refresh, "Rescan") }
        }
        SegmentedPills(
            listOf("Songs", "Albums", "Artists", "Lists", "Folders"), tab, { tab = it },
            Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
        )
        when (tab) {
            0 -> if (songs.isEmpty()) EmptyState("No songs found.") else LazyColumn(contentPadding = PaddingValues(bottom = pad)) {
                item {
                    Row(Modifier.padding(horizontal = 20.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { vm.player.play(songs, 0) }) {
                            Icon(Icons.Rounded.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Play all")
                        }
                        FilledTonalButton(onClick = { vm.player.play(songs.shuffled(), 0, true) }) {
                            Icon(Icons.Rounded.Shuffle, null); Spacer(Modifier.width(6.dp)); Text("Shuffle")
                        }
                    }
                }
                itemsIndexed(songs, key = { _, s -> s.id }) { i, s ->
                    SongRow(s, vm, ps.currentId == s.id, onClick = { vm.player.play(songs, i) })
                }
            }
            1 -> if (albums.isEmpty()) EmptyState("No albums found.") else LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = pad),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                items(albums, key = { it.id }) { a ->
                    Column(Modifier.clickable { onOpenAlbum(a.id) }) {
                        ArtImage(a.songs.first(), Modifier.fillMaxWidth().aspectRatio(1f), androidx.compose.foundation.shape.RoundedCornerShape(20.dp))
                        Spacer(Modifier.height(6.dp))
                        Text(a.name, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                        Text(a.artist, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            2 -> if (artists.isEmpty()) EmptyState("No artists found.") else LazyColumn(contentPadding = PaddingValues(bottom = pad)) {
                items(artists, key = { it.name }) { a ->
                    ListItem(
                        headlineContent = { Text(a.name, fontWeight = FontWeight.SemiBold) },
                        supportingContent = { Text("${a.albumCount} albums • ${a.songs.size} songs") },
                        leadingContent = { ArtImage(a.songs.first(), Modifier.size(52.dp), CircleShape) },
                        modifier = Modifier.clickable { onOpenArtist(Uri.encode(a.name)) },
                        colors = ListItemDefaults.colors(containerColor = androidx.compose.ui.graphics.Color.Transparent),
                    )
                }
            }
            4 -> FolderTab(vm, folders, settings.excluded, onOpenFolder, pad)
            else -> LazyColumn(contentPadding = PaddingValues(bottom = pad)) {
                item {
                    ListItem(
                        headlineContent = { Text("New playlist", fontWeight = FontWeight.SemiBold) },
                        leadingContent = { Icon(Icons.Rounded.Add, null) },
                        modifier = Modifier.clickable { newPlaylist = true },
                        colors = ListItemDefaults.colors(containerColor = androidx.compose.ui.graphics.Color.Transparent),
                    )
                }
                item {
                    ListItem(
                        headlineContent = { Text("Favorites", fontWeight = FontWeight.SemiBold) },
                        leadingContent = { Icon(Icons.Rounded.Favorite, null, tint = MaterialTheme.colorScheme.primary) },
                        modifier = Modifier.clickable { onOpenCollection("favorites") },
                        colors = ListItemDefaults.colors(containerColor = androidx.compose.ui.graphics.Color.Transparent),
                    )
                }
                item { NavRow("Most played", Icons.Rounded.TrendingUp) { onOpenCollection("mostplayed") } }
                item { NavRow("Never played", Icons.Rounded.NewReleases) { onOpenCollection("never") } }
                item { NavRow("Added this week", Icons.Rounded.Today) { onOpenCollection("week") } }
                item { NavRow("Listening stats", Icons.Rounded.BarChart, onOpenStats) }
                items(playlists, key = { it.id }) { p ->
                    ListItem(
                        headlineContent = { Text(p.name, fontWeight = FontWeight.SemiBold) },
                        supportingContent = { Text("${p.songs.size} songs") },
                        leadingContent = { Icon(Icons.Rounded.QueueMusic, null) },
                        modifier = Modifier.clickable { onOpenPlaylist(p.id) },
                        colors = ListItemDefaults.colors(containerColor = androidx.compose.ui.graphics.Color.Transparent),
                    )
                }
            }
        }
    }
    if (newPlaylist) {
        TextPromptDialog("New playlist", confirm = "Create", onDismiss = { newPlaylist = false }) {
            vm.createPlaylist(it); newPlaylist = false
        }
    }
}

@Composable
private fun NavRow(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    ListItem(
        headlineContent = { Text(title, fontWeight = FontWeight.SemiBold) },
        leadingContent = { Icon(icon, null) },
        modifier = Modifier.clickable(onClick = onClick),
        colors = ListItemDefaults.colors(containerColor = androidx.compose.ui.graphics.Color.Transparent),
    )
}

@Composable
private fun FolderTab(vm: MainViewModel, folders: List<Pair<String, Int>>, excluded: Set<String>, onOpen: (String) -> Unit, pad: Dp) {
    if (folders.isEmpty()) { EmptyState("No folders found."); return }
    LazyColumn(contentPadding = PaddingValues(bottom = pad)) {
        item {
            Text(
                "Use the switch to hide a folder from your library.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
            )
        }
        items(folders, key = { it.first }) { (path, count) ->
            val off = path in excluded
            ListItem(
                headlineContent = { Text(path.substringAfterLast('/').ifBlank { path }, fontWeight = FontWeight.SemiBold) },
                supportingContent = { Text("$path • $count songs") },
                leadingContent = { Icon(Icons.Rounded.Folder, null) },
                trailingContent = { Switch(checked = !off, onCheckedChange = { vm.toggleFolder(path) }) },
                modifier = Modifier.clickable(enabled = !off) { onOpen(Uri.encode(path)) },
                colors = ListItemDefaults.colors(containerColor = androidx.compose.ui.graphics.Color.Transparent),
            )
        }
    }
}
