package com.music.echo.offline.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "favorites")
data class FavoriteEntity(@PrimaryKey val songId: Long, val addedAt: Long)

@Entity(tableName = "history")
data class HistoryEntity(@PrimaryKey val songId: Long, val playCount: Int, val lastPlayed: Long)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long,
)

@Entity(tableName = "playlist_songs", primaryKeys = ["playlistId", "songId"])
data class PlaylistSongEntity(val playlistId: Long, val songId: Long, val position: Int)

@Dao
interface EchoDao {
    @Query("SELECT * FROM favorites ORDER BY addedAt DESC") fun favorites(): Flow<List<FavoriteEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun addFavorite(f: FavoriteEntity)
    @Query("DELETE FROM favorites WHERE songId = :id") suspend fun removeFavorite(id: Long)

    @Query("SELECT * FROM history ORDER BY lastPlayed DESC") fun history(): Flow<List<HistoryEntity>>
    @Query("SELECT * FROM history WHERE songId = :id") suspend fun historyFor(id: Long): HistoryEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertHistory(h: HistoryEntity)
    @Query("DELETE FROM history") suspend fun clearHistory()

    @Query("SELECT * FROM playlists ORDER BY createdAt DESC") fun playlists(): Flow<List<PlaylistEntity>>
    @Insert suspend fun insertPlaylist(p: PlaylistEntity): Long
    @Query("UPDATE playlists SET name = :name WHERE id = :id") suspend fun renamePlaylist(id: Long, name: String)
    @Query("DELETE FROM playlists WHERE id = :id") suspend fun deletePlaylist(id: Long)
    @Query("DELETE FROM playlist_songs WHERE playlistId = :id") suspend fun clearPlaylistSongs(id: Long)

    @Query("SELECT * FROM playlist_songs ORDER BY playlistId, position")
    fun allPlaylistSongs(): Flow<List<PlaylistSongEntity>>
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun addToPlaylist(e: PlaylistSongEntity)
    @Query("SELECT COALESCE(MAX(position), -1) + 1 FROM playlist_songs WHERE playlistId = :id")
    suspend fun nextPosition(id: Long): Int
    @Query("DELETE FROM playlist_songs WHERE playlistId = :p AND songId = :s")
    suspend fun removeFromPlaylist(p: Long, s: Long)
}

@Database(
    entities = [FavoriteEntity::class, HistoryEntity::class, PlaylistEntity::class, PlaylistSongEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class EchoDatabase : RoomDatabase() {
    abstract fun dao(): EchoDao

    companion object {
        fun build(ctx: Context): EchoDatabase =
            Room.databaseBuilder(ctx, EchoDatabase::class.java, "echo_offline.db").build()
    }
}
