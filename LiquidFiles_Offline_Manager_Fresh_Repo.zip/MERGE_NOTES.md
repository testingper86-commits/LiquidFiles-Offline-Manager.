# Liquid Glass Offline — merged build source

## Included
- Echo Offline Compose music player and Media3 playback service.
- Liquid Glass file manager as a dedicated Browse destination, with the existing file operations, favorites, recycle bin, vault, duplicate finder, local Wi-Fi transfer and built-in viewer.
- Built-in file viewer includes audio/video playback; video playback speed and loop controls are present in the source.
- iPhone-inspired floating glass navigation from the music UI and glass surfaces in the file manager.
- Removed visible Recent/History shelves from Home and Library, and removed the file manager's “Recent files” panel.
- Renamed the file manager's “Files” navigation label to “Browse” to make the sections clearer.
- The music app home uses the merged “Liquid Glass” branding.

## Important permission note
The app requests broad file access for file-manager operations and an Internet permission for optional local Wi-Fi transfer. Internet access is not needed for local music/video playback. Do not describe the app as requiring no network permission.

## Not verified
This ZIP has not yet passed an Android Gradle build or device test in this session. File access, audio service behavior, video controls, app-lock/vault, and local Wi-Fi transfer need runtime testing on Android. A successful ZIP integrity check is not a successful app build.
