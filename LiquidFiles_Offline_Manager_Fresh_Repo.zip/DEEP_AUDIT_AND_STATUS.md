# Deep upgrade pass 3 — implementation and audit record

## Implemented in this pass
- Reframed the music-player home header as "Your library" with more useful offline-library context.
- Added actionable empty-library guidance to rescan from Settings and keep music local.
- Refined Compose glass surface treatment with a layered tint and a fine specular rim.
- Retained existing player callbacks and collection/album navigation.
- No new runtime dependencies added.

## Deep audit findings from the project source
- The repository contains two app experiences: a native Java file manager (`com.music.echo.offline.files.MainActivity`) and a Kotlin/Compose Media3 music player (`com.music.echo.offline.ui.MainActivity`). The manifest launches the native file manager; the music service and Compose player remain in the same APK.
- `app/build.gradle.kts` uses Android Gradle Plugin via root configuration, Kotlin Compose plugin, KSP/Room, Compose BOM, Media3 and DataStore. A reproducible Gradle wrapper JAR is not included; CI installs Gradle directly.
- The Compose `SettingsScreen` already groups appearance, library, audio, data, and about settings. A separate native file-manager settings experience also exists; both need runtime navigation review to ensure settings changes are not split/confusing.
- `AndroidManifest.xml` requests broad storage access, package install permission, and INTERNET for optional LAN transfer. The README's older claim that no INTERNET permission is declared is inconsistent with the manifest and should not be repeated. MANAGE_EXTERNAL_STORAGE is a sensitive permission requiring a clear rationale and policy review before Play distribution.
- Heroicons MIT license and attribution files are bundled. Individual icon assets should be traceable to the upstream Heroicons distribution; bundled SVG assets do not automatically prove that all icons throughout the app are from Heroicons.
- The `Glass.kt` Compose modifier creates translucent tinted surfaces and a rim; it does not perform true backdrop blur. Native Java `Ui.glass` likewise uses layered drawables rather than backdrop blur.
- Existing functionality source files were retained; source presence alone does not prove the behavior works.

## Not yet verified
- Android compile / assembleDebug, installation, launch, and device testing.
- True backdrop blur and visual consistency across API levels.
- End-to-end file operations, storage permission flows, SD/USB storage, archive safety, vault security, LAN transfer, media playback and video playback.
- Full accessibility, icon-by-icon provenance, and license review of third-party dependencies.
- Full File Manager Plus-inspired category counts/storage breakdown and final settings redesign.

## Recommended build verification
Run the repository GitHub Actions Android Build workflow and inspect compile output. Then install the generated debug APK and exercise the smoke-test checklist before treating the app as complete.
